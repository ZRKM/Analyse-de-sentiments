# Covid-19_Tweets_Sentiment-Analysis
This project concerns the analysis of feelings which is a common task of NLP, which consists in classifying texts or parts of texts in a predefined feeling. In our case, the data is in the form of tweets concerning Covid 19.

## Below is the link for the video illustrating the presentation of the mini-project
https://drive.google.com/file/d/1OQPasGzDcS19loVXp7wNS_CGXtFnhgrG/view?usp=sharing
